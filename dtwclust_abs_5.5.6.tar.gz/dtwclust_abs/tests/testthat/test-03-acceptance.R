context("Acceptance tests")

source("acceptance/dtwb.R", TRUE)
source("acceptance/gak.R", TRUE)
source("acceptance/lbs.R", TRUE)
source("acceptance/symmetric-proxy.R", TRUE)
