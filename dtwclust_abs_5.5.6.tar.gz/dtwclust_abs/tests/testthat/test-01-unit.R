context("Unit tests")

source("unit/methods.R", TRUE)
source("unit/misc.R", TRUE)
source("unit/distances.R", TRUE)
source("unit/centroids.R", TRUE)
source("unit/cvis.R", TRUE)
source("unit/configs.R", TRUE)
