context("Integration tests")

source("integration/proxy.R", TRUE)
source("integration/families.R", TRUE)
source("integration/custom-dist.R", TRUE)
