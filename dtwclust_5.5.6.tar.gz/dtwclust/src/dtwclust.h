#ifndef DTWCLUST_HPP_
#define DTWCLUST_HPP_

#include "centroids/R-gateways.h"
#include "distances/R-gateways.h"
#include "distmat/R-gateways.h"
#include "tadpole/R-gateways.h"
#include "utils/R-gateways.h"

#endif // DTWCLUST_HPP_
